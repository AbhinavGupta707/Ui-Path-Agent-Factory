# Setup

This guide gets a reviewer from a fresh clone to the current local demo. It also lists the safe UiPath read-only checks that prove the Automation Cloud context without mutating live assets.

## 1. Local Prerequisites

```bash
node --version
npm --version
codex --version
uip --version
gh --version
vercel --version
```

Expected working state:

- Node.js 22+
- npm 10+
- Codex CLI 0.142+
- UiPath CLI 1.195.x authenticated to `galacticus / DefaultTenant`
- GitHub CLI authenticated if PR creation is enabled
- Vercel CLI authenticated only when a deployment lane provides hosted sandbox commands

## 2. Install And Verify

```bash
npm install
npm run smoke
```

`npm run smoke` runs workspace builds and tests. It is the fastest single check for reviewers before opening the demo.

## 3. Run The Local Demo

Checkpoint 6 preferred startup:

```bash
npm run setup:live
```

```bash
npm run dev:live
```

`setup:live` writes git-ignored local configuration and masks provider prompts. `dev:live` builds the shared packages/services and starts the API, worker, Factory Console, and Customer360 dashboard together.

Default Checkpoint 6 endpoints:

| Surface | URL |
|---|---|
| Factory API health | `http://localhost:8887/health` |
| Build Worker health | `http://localhost:8890/health` |
| Factory Console | `http://localhost:5183` |
| Customer360 dashboard | `http://localhost:5184` |

If you need the older separate-terminal path, start each service after `npm run smoke` or `npm run build`:

Build before starting the Factory API because its dev command watches compiled output:

```bash
npm --workspace @agent-factory/factory-api run build
FACTORY_API_PORT=8787 npm run dev:api
```

```bash
npm run dev:worker
```

```bash
npm run dev:console
```

```bash
npm run dev:customer360
```

Default separate-terminal endpoints:

| Surface | URL |
|---|---|
| Factory API health | `http://localhost:8787/health` |
| Build Worker health | `http://localhost:8790/health` |
| Factory Console | Vite output, usually `http://localhost:5173` |
| Customer360 dashboard | `http://localhost:5174` |

The Factory API uses an in-memory store. Restarting `npm run dev:api` resets local request state.

See [Checkpoint 6 live demo runbook](live-demo-runbook.md) for the manual workflow, provider validation posture, demo-video narration notes, and claim boundaries.

## 4. Optional API Rehearsal

The Factory Console is the primary demo surface, but the same lifecycle can be driven from the API:

```bash
curl -s http://localhost:8787/health
```

```bash
curl -s -X POST http://localhost:8787/api/requests \
  -H "content-type: application/json" \
  -d '{"requester_name":"Avery Morgan","requester_email":"avery@example.com","request_text":"I need a governed Customer360 analytics dashboard for revenue operations.","owner_name":"Revenue Ops","owner_email":"revops@example.com"}'
```

For a freshly restarted API, the first request id is `REQ-2026-001`:

```bash
curl -s -X POST http://localhost:8787/api/requests/REQ-2026-001/clarify
curl -s -X POST http://localhost:8787/api/requests/REQ-2026-001/answers \
  -H "content-type: application/json" \
  -d '{"answers":[{"question_id":"pii_policy","answer":"Mask names/emails/phones","answered_by":"Avery Morgan"},{"question_id":"approved_sources","answer":"synthetic_customers_csv, synthetic_orders_csv, synthetic_events_csv, synthetic_returns_csv","answered_by":"Avery Morgan"},{"question_id":"approved_metrics","answer":"revenue, average_order_value, repeat_purchase_rate, churn_risk_proxy","answered_by":"Avery Morgan"},{"question_id":"required_filters","answer":"date_range, channel, product_category, segment","answered_by":"Avery Morgan"},{"question_id":"approval_owner","answer":"Revenue Ops","answered_by":"Avery Morgan"}]}'
curl -s -X POST http://localhost:8787/api/requests/REQ-2026-001/spec
curl -s -X POST http://localhost:8787/api/requests/REQ-2026-001/govern
curl -s -X POST http://localhost:8787/api/requests/REQ-2026-001/approve-scope \
  -H "content-type: application/json" \
  -d '{"comments":"Approved for sandbox build."}'
curl -s -X POST http://localhost:8787/api/requests/REQ-2026-001/manifest
curl -s -X POST http://localhost:8787/api/builds \
  -H "content-type: application/json" \
  -d '{"request_id":"REQ-2026-001","manifest_id":"MAN-REQ-2026-001","mode":"sandbox"}'
curl -s -X PATCH http://localhost:8787/api/builds/BUILD-REQ-2026-001-001/status \
  -H "content-type: application/json" \
  -d '{"status":"building","worker_id":"local-worker-1","generated_files_json":["src/main.tsx","tests/dashboard.test.tsx"]}'
curl -s http://localhost:8787/api/requests/REQ-2026-001/timeline
```

## 5. Sandbox Deployment Evidence

The Checkpoint 5 deployment contract is available at `POST http://localhost:8787/deploy`. It is idempotent by `operationId` or `x-agent-factory-operation-id`, refuses production deployment, and records sandbox evidence for the audit trail.

```bash
curl -X POST http://localhost:8787/deploy \
  -H "content-type: application/json" \
  -H "x-agent-factory-operation-id: deploy_req_2026_001_001" \
  -d '{"requestId":"REQ-2026-001","platformMode":"uipath-ready","buildRunId":"BUILD-REQ-2026-001-001","environment":"sandbox","deploymentUrl":"http://localhost:5174","deploymentProvider":"local-sandbox","releaseApproval":{"status":"approved","approvalId":"appr_req_2026_001_release_001","decidedBy":"release-approver"}}'
```

For `uipath-live` trusted bridge callbacks, include
`-H "x-agent-factory-bridge-token: $AGENT_FACTORY_BRIDGE_TOKEN"` and keep the
actual value in a git-ignored environment or Orchestrator asset.

For a dry-run command bundle:

```bash
node scripts/deploy-sandbox.mjs --target=customer360
```

See [Deployment](deployment.md) for the full request contract, Vercel preview fallback, rollback notes, and approval boundaries.

## 6. Customer360 Refresh Proof

The dashboard has built-in Baseline, Degraded, Empty, and Refresh controls. Automated checks also prove deterministic data mutation:

```bash
npm run smoke:customer360
```

The standalone mutation helper writes an untracked data file for evidence or future deployment lanes:

```bash
node scripts/mutate-customer360-data.mjs --seed 20260715
```

## 7. UiPath Read-Only Checks

Use CLI checks before browser automation:

```bash
uip login status --output json
uip or folders get AgentFactoryDemo --output json
uip tm project list --limit 5 --output json
uip tm testcases list --project-key AFQG --output json
uip tm testsets list --project-key AFQG --output json
uip tm testsets list-testcases --project-key AFQG --test-set-key AFQG:1 --output json
uip maestro bpmn validate uipath/maestro/customer360-build/agent-factory-customer360-build.bpmn --output json
```

Optional local Codex skill setup:

```bash
uip skills install --agent codex --local
```

Generated skill bundles are intentionally ignored by git.

## 8. Provider And Trace Checks

Fireworks and LangSmith belong in server-side runtime configuration, not in UI copy or docs. Check only registration and activation state first:

```bash
npm run demo:scan
npm run smoke:demo
```

Then confirm local provider setup with the owner of the configured environment. Record model profile names, project name, HTTP status, and sanitized trace links only. Do not paste provider values, local configuration contents, or full trace payloads into docs, chat, terminal transcripts, or screenshots.

## 9. Approval Boundaries

These actions are live mutations or side-effecting runtime calls and require explicit approval:

- Data Service choice-set/entity/record creation
- Maestro publish or run
- Agent solution upload, publish, deploy, or run
- API Workflow upload or runtime calls
- Action Center task creation or completion
- UiPath Apps coded app publish or deploy
- Live Test Manager/Test Cloud execution
- Deploying to a production target
